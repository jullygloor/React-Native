import React, { useState } from 'react';
import {
  View,
  Text,
  Switch,
  StyleSheet,
  TouchableOpacity,
  Alert,
  useColorScheme,
} from 'react-native';
import styles from '../src/styles/SettingsScreenStyles';



const SettingsScreen = ({ navigation }) => {
  const systemTheme = useColorScheme(); // 'light' ou 'dark'
  const [darkMode, setDarkMode] = useState(systemTheme === 'dark');

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleLogout = () => {
    Alert.alert('Sair', 'Tem certeza que deseja sair?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sair', onPress: () => console.log('Usuário saiu') },
    ]);
  };

  const isDark = darkMode;
  const backgroundColor = isDark ? '#121212' : '#FFF';
  const textColor = isDark ? '#FFF' : '#000';
  const borderColor = isDark ? '#444' : '#DDD';

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Text style={[styles.header, { color: textColor }]}>Configurações</Text>

      <View style={[styles.item, { borderBottomColor: borderColor }]}>
        <Text style={[styles.label, { color: textColor }]}>Modo Escuro</Text>
        <Switch value={darkMode} onValueChange={toggleDarkMode} />
      </View>

      <TouchableOpacity
        style={[styles.item, { borderBottomColor: borderColor }]}
        onPress={() => navigation.navigate('Conta')}
      >
        <Text style={[styles.label, { color: textColor }]}>Conta</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.item, { borderBottomColor: borderColor }]}
        onPress={() => navigation.navigate('NotificationSettings')}
      >
        <Text style={[styles.label, { color: textColor }]}>Notificações</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.logoutButton, { backgroundColor: '#FF3B30' }]}
        onPress={handleLogout}
      >
        <Text style={styles.logoutText}>Sair</Text>
      </TouchableOpacity>
    </View>
  );
};

export default SettingsScreen;

