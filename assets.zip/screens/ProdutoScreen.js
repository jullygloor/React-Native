import React from 'react';
import { StyleSheet, Text, View, FlatList, Image } from 'react-native';
import styles from '../src/styles/ProdutoScreenStyles';

const newsData = [
  {
    id: '1',
    title: 'Bolo de Morango com Chocolate com Morango',
    description: 'R$ 128,99',
    imagem: 'https://static.itdg.com.br/images/auto-auto/782bd793e3dc27f211267475d633b4e1/receitas-rapidas-de-doce.jpg',
  },
  {
    id: '2',
    title: 'macarons coloridos ',
    description: 'R$ 18,28',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVLOjnRrQP3EEWKycHhsZCfOR1fD9m8poPOoptx269kG6g7gPkp8phrJULEGjLVhf9MbA&usqp=CAU', // substituído por URL válida
  },
  {
    id: '3',
    title: 'Bolo Branco Com recheio de Nutella com muito Morango',
    description: 'R$ 209,20',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQP29qsjFIDcjAsWdTR8oo7XCx8WCsrJvei6DRoKVvuKN_Y9XtMhO1cEV6atEpj4XbSCmo&usqp=CAU', // substituído por URL válida
  },
];

const getBackgroundColor = (id) => {
  switch (id) {
    case '1':
      return '#ffffff';
    case '2':
      return '#ffffff';
    case '3':
      return '#ffffff';
    default:
      return '#ffffff';
  }
};

const NewsItem = ({ item }) => {
  return (
    <View style={[styles.newsItem, { backgroundColor: getBackgroundColor(item.id) }]}>
      <Image source={{ uri: item.imagem }} style={styles.productImage} />
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.description}>{item.description}</Text>
    </View>
  );
};

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Produtos</Text>
      <FlatList
        data={newsData}
        renderItem={({ item }) => <NewsItem item={item} />}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}
