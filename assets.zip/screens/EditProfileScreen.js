import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  Alert,
} from 'react-native';
import styles from '../src/styles/EditProfilesScreenStyles';




const EditProfileScreen = ({ navigation }) => {
  const theme = useColorScheme();
  const isDark = theme === 'dark';

  // Simula dados carregados do usuário
  const [name, setName] = useState('Astarote');
  const [email, setEmail] = useState('Asta_Borreto@email.com');

  const handleSave = () => {
    // Aqui você pode integrar com backend/Firebase/etc
    Alert.alert('Perfil Atualizado', 'Suas informações foram salvas.');
    navigation.goBack(); // Volta pra tela anterior
  };

  return (
    <View style={[styles.container, { backgroundColor: isDark ? '#121212' : '#FFF' }]}>
      <Text style={[styles.label, { color: isDark ? '#FFF' : '#000' }]}>Nome</Text>
      <TextInput
        style={[styles.input, { color: isDark ? '#FFF' : '#000', borderColor: isDark ? '#555' : '#CCC' }]}
        value={name}
        onChangeText={setName}
        placeholder="Digite seu nome"
        placeholderTextColor={isDark ? '#AAA' : '#888'}
      />

      <Text style={[styles.label, { color: isDark ? '#FFF' : '#000' }]}>Email</Text>
      <TextInput
        style={[styles.input, { color: isDark ? '#FFF' : '#000', borderColor: isDark ? '#555' : '#CCC' }]}
        value={email}
        onChangeText={setEmail}
        placeholder="Digite seu email"
        placeholderTextColor={isDark ? '#AAA' : '#888'}
        keyboardType="email-address"
      />

      <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
        <Text style={styles.saveText}>Salvar</Text>
      </TouchableOpacity>
    </View>
  );
};

export default EditProfileScreen;

