import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import styles from '../src/styles/AccountScreenStyles';

const AccountSettingsScreen = ({ navigation }) => {
  const user = {
    name: 'Astarote',
    email: 'Asta_Borreto@email.com',
    avatar: 'https://media.licdn.com/dms/image/v2/D4D03AQEd3XXy07OITA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1720880917082?e=2147483647&v=beta&t=UaISg07XzXVMjTcH6PWikWfBcPiNh48jgafh7jCai6U', // Avatar fake de exemplo
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri: user.avatar }} style={styles.avatar} />

      <Text style={styles.name}>{user.name}</Text>
      <Text style={styles.email}>{user.email}</Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Editar')}
      >
        <Text style={styles.buttonText}>Editar Perfil</Text>
      </TouchableOpacity>
    </View>
  );
};

export default AccountSettingsScreen;


